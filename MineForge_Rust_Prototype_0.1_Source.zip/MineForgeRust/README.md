# MineForge Rust — Android prototype 0.1

This is the first source-code scaffold for the MineForge Rust version manager UI.

## Included
- Android Kotlin + Jetpack Compose project.
- Dark navy / gold interface inspired by the supplied ETS2 version-manager screenshot.
- Default Minecraft profile placeholder (26.3).
- Android Storage Access Framework ZIP picker.
- In-memory list of selected ZIP packages.

## Not implemented yet
- ZIP extraction, archive validation, metadata parsing, or profile persistence.
- Minecraft Java runtime, libraries, assets, authentication, or game launching.
- Starling/Horizon engine integration.
- Native Rust `.hnmod` loading or Fabric/Forge/NeoForge support.
- APK signing or release build.

The APK supplied by the user is a compiled Starling binary, not its source code. A real fork/integration requires the corresponding source repository and license/notice review. Do not redistribute a modified Starling build until its license obligations and upstream notices are verified.

## Build
Open this folder in Android Studio (recent stable version), let Gradle sync, then build the `app` debug variant. This scaffold has not been compiled or tested on a device in this environment.
