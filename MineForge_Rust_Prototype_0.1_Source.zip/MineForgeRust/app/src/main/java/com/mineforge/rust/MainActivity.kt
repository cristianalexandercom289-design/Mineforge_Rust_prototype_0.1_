package com.mineforge.rust

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Navy = Color(0xFF0B1D28)
private val Panel = Color(0xFF142D3B)
private val Gold = Color(0xFFF0C568)
private val Muted = Color(0xFFA8BAC4)

data class ImportedPackage(val name: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var packages by remember { mutableStateOf(listOf<ImportedPackage>()) }
            var selected by remember { mutableStateOf("26.3 (perfil predeterminado)") }
            var message by remember { mutableStateOf("Importa un ZIP para inspeccionarlo. La importación todavía no instala ni ejecuta Minecraft.") }
            val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri != null) {
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: SecurityException) { }
                    val name = queryName(uri) ?: "Paquete importado"
                    if (!name.endsWith(".zip", ignoreCase = true)) {
                        message = "Selecciona un archivo ZIP. No se ha importado nada."
                    } else {
                        packages = packages + ImportedPackage(name, uri)
                        selected = name
                        message = "ZIP añadido a la lista. Falta validar su estructura y dependencias antes de poder ejecutarlo."
                    }
                }
            }
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Navy, surface = Panel)) {
                Column(Modifier.fillMaxSize().background(Navy).padding(18.dp)) {
                    Text("MINEFORGE RUST", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Text("ANDROID EDITION  •  PROTOTIPO 0.1", color = Gold, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(22.dp))
                    Text("Versiones", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Tu instalación predeterminada y versiones importadas, con perfiles separados.", color = Muted)
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = { picker.launch(arrayOf("application/zip", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy), shape = RoundedCornerShape(28.dp)) {
                        Text("IMPORTAR ARCHIVO ZIP", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(12.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("PREDETERMINADA", color = Gold, style = MaterialTheme.typography.labelLarge)
                            Text("Minecraft Java 26.3", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Perfil reservado · No incluye archivos del juego", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("PAQUETES IMPORTADOS", color = Gold, fontWeight = FontWeight.Bold)
                    if (packages.isEmpty()) Text("Todavía no has importado versiones.", color = Muted, modifier = Modifier.padding(vertical = 16.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(packages) { item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                        Text("ZIP seleccionado · pendiente de validar", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    }
                                    RadioButton(selected = selected == item.name, onClick = { selected = item.name })
                                }
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF203D4D)), modifier = Modifier.fillMaxWidth()) {
                        Text(message, color = Color.White, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("MineForge Rust es un prototipo de interfaz. El motor, el inicio de sesión y la ejecución de versiones aún no están integrados.", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }

    private fun queryName(uri: Uri): String? = contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (index >= 0 && cursor.moveToFirst()) cursor.getString(index) else null
    }
}
